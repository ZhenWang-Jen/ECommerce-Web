﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AtoZBook
{
    public partial class AtoZSearch : System.Web.UI.Page
    {
        public static string text;
        protected void Page_Load(object sender, EventArgs e)
        {
            /*string dbServer = "cis425.wpcarey.asu.edu"; // "<Server IP or Hostname>"
            string username = "yjian112";               // "<DB username>"
            string password = "radioSAIL37";            // "<DB password>"
            string dbName = "group6";               // "<DB Name>"

            string dbConnectionString = string.Format("server={0};uid={1};pwd={2};database={3};", dbServer, username, password, dbName);
            var conn = new MySql.Data.MySqlClient.MySqlConnection(dbConnectionString);
            conn.Open();

            //string query = "SELECT * FROM book where";

            var cmd = new MySql.Data.MySqlClient.MySqlCommand(query, conn);
            var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                var titleValue = reader["Title"]; //get data from the 'Title' column
                var isbnValue = reader["isbn"];

                //Do something with the retrieved values
                testLbl.Text += "Book title is " + titleValue.ToString()
                                            + " and its ISBN is " + isbnValue.ToString()
                                            + "<br>";
            }

            reader.Close();

            conn.Close();*/

            testLbl.Text += text;

        }

        public static void Search(string x)
        {
            string dbServer = "cis425.wpcarey.asu.edu"; // "<Server IP or Hostname>"
            string username = "yjian112";               // "<DB username>"
            string password = "radioSAIL37";            // "<DB password>"
            string dbName = "group6";               // "<DB Name>"

            string dbConnectionString = string.Format("server={0};uid={1};pwd={2};database={3};", dbServer, username, password, dbName);
            var conn = new MySql.Data.MySqlClient.MySqlConnection(dbConnectionString);
            conn.Open();

            string query = "SELECT * FROM book WHERE Title LIKE '%" + x + "%';";

            var cmd = new MySql.Data.MySqlClient.MySqlCommand(query, conn);
            var reader = cmd.ExecuteReader();


            while (reader.Read())
            {
                var titleValue = reader["Title"]; //get data from the 'Title' column
                var isbnValue = reader["isbn"];

                //Do something with the retrieved values
                text = "Book title is " + titleValue.ToString()
                                            + " and its ISBN is " + isbnValue.ToString()
                                            + "<br>";
            }

            reader.Close();

            conn.Close();
        }
        
    }
}
﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(AtoZBook.Startup))]
namespace AtoZBook
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}

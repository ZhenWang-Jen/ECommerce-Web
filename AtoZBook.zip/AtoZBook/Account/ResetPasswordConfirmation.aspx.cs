﻿using System.Web.UI;

namespace AtoZBook.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace AtoZBook
{
    public partial class AtoZHome : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void srchImg_Click(object sender, ImageClickEventArgs e)
        {
            string userInput = searchTxtBx.Text;
            AtoZSearch.Search(userInput);
            Response.Redirect("AtoZSearch.aspx");
        }

       
    }
}